package com.example.acer.alarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
    ToggleButton toggle;
    AlarmManager manager;
    PendingIntent pi;
    public static final String Broadcast ="com.example.acer.alarm.BROADCAST";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toggle=findViewById(R.id.toggle);
        manager= (AlarmManager) getSystemService(ALARM_SERVICE);
        Intent i =new Intent(Broadcast);
         pi=PendingIntent.getBroadcast(this,0,i,PendingIntent.FLAG_UPDATE_CURRENT);
        toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    long trigger = SystemClock.elapsedRealtime() + (1 * 60 * 1000);
                    long interval = 1 * 60 * 1000;
                    manager.setInexactRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP,trigger,interval,pi);
                    Toast.makeText(MainActivity.this, "Toggle is on", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(MainActivity.this, "Toggle is off", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    public void off(View view) {
    }
}
